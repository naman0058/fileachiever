let quizname = []
let quiz_topic = []
let createquiz = []

start()
$.getJSON(`/quiz_name/all`, data => {
    quizname = data
    fillDropDown('quizid', data, 'Choose Quiz Name', 0)
})



$.getJSON(`/quiz_topic/all`, data => {
    quiz_topic = data
    fillDropDown('quiztopicid', [], 'Choose Quiz Topic', 0)
})

$('#quizid').change(() => {
    const filteredData = quiz_topic.filter(item => item.quizid == $('#quizid').val())
    fillDropDown('quiztopicid', filteredData, 'Choose Board', 0)
})

function fillDropDown(id, data, label, selectedid = 0) {
    $(`#${id}`).empty()
    $(`#${id}`).append($('<option>').val("null").text(label))

    $.each(data, (i, item) => {
        if (item.id == selectedid) {
            $(`#${id}`).append($('<option selected>').val(item.id).text(item.name))
        } else {
            $(`#${id}`).append($('<option>').val(item.id).text(item.name))
        }
    })
}
$('#show').click(function(){
$.getJSON(`create_quiz/all`, data => {
    createquiz = data
    makeTable(data)
})
})


function makeTable(subject){
    let table = ` <div class="row mt-5">
    <div class="col">
      <div class="card bg-default shadow">
        <div class="card-header bg-transparent border-0">
          <h3 class="text-white mb-0">All createquiz</h3>
          <br>
          <button type="button" id="back" class="btn btn-sm btn-primary">BacK</button>
        </div>
       
      
      
        <div class="table-responsive">
          <table class="table align-items-center table-dark table-flush">
            <thead class="thead-dark">
              <tr>
                <th scope="col">Quiz Name</th>
                <th scope="col">Quiz Topic</th>
                <th scope="col">Question</th>
                <th scope="col">All Options</th>
                <th scope="col">Answers</th>
              </tr>
            </thead>
            <tbody>
                  <tr>`
                  $.each(subject, function(i, item) {
                      table += `<th scope="row">
                      <div class="media align-items-center">
                      <span class="mb-0 text-sm">${item.quizname}</span>
                      
                      
                    </th>

                    <th scope="row">
                      <div class="media align-items-center">
                      <span class="mb-0 text-sm">${item.quiztopicname}</span>
                         </th>

                         <th scope="row">
                         <div class="media align-items-center">
                         <span class="mb-0 text-sm">${item.question}</span>
                            </th>

                            <th scope="row">
                            <div class="media align-items-center">
                            <span class="mb-0 text-sm">${item.options1} , ${item.options2} , ${item.options3} , ${item.options4}</span>
                               </th>

                               <th scope="row">
                               <div class="media align-items-center">
                               <span class="mb-0 text-sm">${item.answer}</span>
                                  </th>

                  
                    <td class="text-right">
                      <div class="dropdown">
                        <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-ellipsis-v"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                        <button class="dropdown-item btn btn-primary edit" id="${item.id}">Edit Data</button>
                       <button class=" dropdown-item btn btn-outline-success delete" id="${item.id}">Delete</button>
                      
                        </div>
                      </div>
                    </td>
                  </tr>`
                  })
                  
              table +=` </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>`
      $('#result').html(table)
      $('#insertdiv').hide()
      $('#result').show()
}




$('#result').on('click', '.delete', function () {
    const id = $(this).attr('id')
    $.get(`create_quiz/delete`, { id }, data => {
        refresh()
    })
})

let selectedBoard = 0

$('#quizidUpdate').change(() => {
    const filteredData = quiz_topic.filter(item => item.quizid == $('#quizidUpdate').val())
    fillDropDown('quiztopicidUpdate', filteredData, 'Choose Sub-Category', 0)
})

$('#result').on('click', '.edit', function () {
    const id = $(this).attr('id')
    const result = createquiz.find(item => item.id == id);
    console.log(result)

    fillDropDown('quizidUpdate', quizname, 'Choose Class', result.quizid)
    $('#quiztopicidUpdate').append($('<option>').val(result.quiztopicid).text(result.quiztopicname))
    edit()
    $('#pid').val(result.id)
    $('#pquestion').val(result.question)
    $('#poptions1').val(result.options1)
    $('#poptions2').val(result.options2)
    $('#poptions3').val(result.options3)
    $('#poptions4').val(result.options4)
    $('#panswer').val(result.answer)
    
})

$('#update').click(function () {  //data insert in database
    let updateobj = {
        id: $('#pid').val(),
        quizid: $('#quizidUpdate').val(),
        quiztopicid: $('#quiztopicidUpdate').val(),
        question: $('#pquestion').val(),
        options1 : $('#poptions1').val(),
          options2 : $('#poptions2').val(),
          options3 : $('#poptions3').val(),
          options4 : $('#poptions4').val(),
          answer : $('#panswer').val(),
      
    }

    $.post(`create_quiz/update`, updateobj, function (data) {
      update()
    })
})



function start()
{
$('#editdiv').hide()
$('#back').hide()
$('#result').hide()
$('#insertdiv').show()
$('#updateimagediv').hide()
}
function insert()
{
     $('#insertdiv').show(1000)
    $('#back').show()
    $('#refresh').hide()
    $('#result').hide()
    $('#editdiv').hide()
}
function back()
{
    $('#refresh').show()
    $('#editdiv').hide()
    $('#back').hide()
    $('#insertdiv').hide()
    $('#result').show(1000)
}
function insertdata()
{
    $('#editdiv').hide()
    $('#back').hide()
    $('#insertdiv').hide()
    $('#refresh').show()
    $('#result').show()
    refresh()
}
function edit()
{
    $('#back').show()
    $('#refresh').hide()
    $('#editdiv').show()
    $('#result').hide()
}
function update()
{
    $('#result').show()
    $('#editdiv').hide()
    $('#insertdiv').hide()
    refresh()
}

$('#new').mouseenter(function () {
    insert()
 })
 
 $('#back').mouseenter(function () {
     back()
 })
 
 function refresh() {
     $.getJSON(`create_quiz/all`, data => {
         makeTable(data)
     })
 }

 //================================Page Functionality=============================//
$('#editdiv').hide()
$('#updateimagediv').hide()

$('#result').on('click', '#back', function() {
    $('#result').hide()
    $('#insertdiv').show()
})

$('#back1').click(function(){
    $('#result').show()
    $('#insertdiv').hide()
    $('#editdiv').hide()
    $('#updateimagediv').hide()

})

$('#back2').click(function(){
    $('#result').show()
    $('#insertdiv').hide()
    $('#editdiv').hide()
    $('#updateimagediv').hide()
})

$('#result').on('click', '.updateimage', function() {
    $('#updateimagediv').show()
    $('#result').hide()
    $('#insertdiv').hide()
    $('#editdiv').hide()
})

//===================================Page Functioality Ends========================//

