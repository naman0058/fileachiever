var express = require('express')
var pool = require('./pool')
var router = express.Router()
var table = 'add_faculty';
var table1 = 'faculty';
// var upload = require('./multer');

router.get('/', (req, res) => {
    if(req.session.adminid) {
    res.render(`${table}/index`);
    }
    else
    {
         res.render(`admin_login`, { login: false, msg:'' });
    }
})

router.post('/insert', (req, res) => {
    let body = req.body;
    body['password'] = '123'
       pool.query(`insert into ${table1} set ?`, body, (err, result) => {
        if(err) throw err;
        else res.send('success')
    })
})



router.get('/all', (req, res) => {
    pool.query(`select * from ${table1}`, (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})

// router.get('/single', (req, res) => {
//     const { id } = req.query
//     pool.query(`select * from ${table} where id = ${id}`, (err, result) => {
//         if(err) throw err;
//         else res.json(result);
//     })
// })

router.get('/delete', (req, res) => {
    const { id } = req.query
    pool.query(`delete from ${table1} where id = ${id}`, (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})

router.post('/update', (req, res) => {
    console.log(req.body)
    pool.query(`update ${table1} set ? where id = ?`, [req.body, req.body.id], (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})



module.exports = router;