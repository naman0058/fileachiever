var express = require('express');
var router = express.Router();
var pool = require('./pool')
var table = 'student'
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('user_login', {msg : ''});
});

router.post('/login', (req, res) => {
  const { email, password } = req.body
  console.log(req.body)
  pool.query(`select * from ${table} where email = "${email}" and password = "${password}"`, (err, result) => {
    if(err) throw err;
    else if (result[0]) {
          console.log(result[0].id)
          req.session.studentid = result[0].id;
          res.redirect('/user-dashboard');
      }
      else
          res.render('user_login',{msg : 'Invalid Creaditianils'});
  })
})


router.get('/logout', (req, res) => {
  req.session.studentid = null;
  res.redirect('/user-login');
})





router.get('/shoes_category',(req,res)=>{
  pool.query(`select * from shoes_category`,(err,result)=>{
    err ? console.log(err) : res.json(result)
  })
})


router.get('/shoes_brand',(req,res)=>{
  pool.query(`select * from shoes_brand`,(err,result)=>{
    err ? console.log(err) : res.json(result)
  })
})



router.post('/shoes_product',(req,res)=>{

pool.query(`select s.*, (select c.name from shoes_category c where c.id = s.categoryid) as categoryname from shoes_product s where s.categoryid = "${req.body.id}"`,(err,result)=>{
  err ? console.log(err) : res.json(result)
})

});






router.post('/shoes_login', (req, res) => {
 let body = req.body
  console.log("login data",req.body)
  pool.query(`select * from shoes_login where email = "${req.body.email}" and password = "${req.body.password}"`, (err, result) => {
    if(err) throw err;
    else if (result[0]) {
          res.json({
            msg : 'success'
          })
      }
      else{
      res.json({
        msg : 'invalid'
      })
    }
  })
})


router.post('/shoes_product_by_brand',(req,res)=>{

  pool.query(`select * from shoes_product where brandid = "${req.body.id}"`,(err,result)=>{
    err ? console.log(err) : res.json(result)
  })
  
  });


  router.post('/single_shoes',(req,res)=>{

    pool.query(`select * from shoes_product where id = "${req.body.id}"`,(err,result)=>{
      err ? console.log(err) : res.json(result)
    })
    
    });



    router.post('/all_product',(req,res)=>{

      pool.query(`select * from shoes_product`,(err,result)=>{
        err ? console.log(err) : res.json(result)
      })
      
      });


      router.post('/booking_successful',(req,res)=>{
        let body = req.body;
        console.log("data",req.body)
       
        pool.query(`insert into shoes_booking set ?`, body, (err, result) => {
          if(err) throw err;
          else res.json({
            msg : 'success'
          })
      })
       
      })




      router.post('/booking_successful_again',(req,res)=>{
        let body = req.body;
        console.log("data",req.body)
       pool.query(`delete from shoes_cart where id = "${req.body.bookingid}"`,(err,result)=>{
         if(err) throw err
         else{
          pool.query(`insert into shoes_booking set ?`, body, (err, result) => {
            if(err) throw err;
            else res.json({
              msg : 'success'
            })
        })
         }
       })
       
       
      })



      router.get('/orders',(req,res)=>{
        pool.query(`select b.*,(select p.image from shoes_product p where p.id = b.bookingid) as booking_image from shoes_booking b order by id desc`,(err,result)=>{
          if(err)  throw err;
          else res.json(result)
        })
      })

  
      router.post('/add_to_cart',(req,res)=>{
        let body = req.body;
        console.log("data",req.body)
        pool.query(`insert into shoes_cart set ?`, body, (err, result) => {
          if(err) throw err;
          else res.json({
            msg : 'success'
          })
      })
       
      })




      router.get('/cart',(req,res)=>{
        pool.query(`select b.*,(select p.image from shoes_product p where p.id = b.bookingid) as booking_image from shoes_cart b order by id desc`,(err,result)=>{
          if(err)  throw err;
          else res.json(result)
        })
      })


      router.post('/remove_cart',(req,res)=>{
        pool.query(`delete from shoes_cart where id = "${req.body.id}"`,(err,result)=>{
          if(err) throw err;
          else res.json({msg:'success'})
        })
      })


module.exports = router;
