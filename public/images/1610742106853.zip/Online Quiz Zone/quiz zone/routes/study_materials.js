var express = require('express');
var router = express.Router();
var pool = require('./pool')

/* GET home page. */
router.get('/', function(req, res, next) {
  pool.query(`select * from study_materials_category`,(err,result)=>{
    err ? console.log(err) :  res.render('study_materials',{result:result});
  })
 
});


router.get('/get_notes',(req,res)=>{
  pool.query(`select * from study_materials_notes where studymaterialsid = "${req.query.id}"`,(err,result)=>{
    err ? console.log(err) : res.render('study_materials_download_notes',{result:result})
  })
})

module.exports = router;
