var express = require('express')
var pool = require('./pool')
var router = express.Router()
var table = 'quiz_topic';
// var upload = require('./multer');

router.get('/', (req, res) => {
    if(req.session.facultyid) {
    res.render(`${table}/index`);
    }
    else
    {
         res.render(`faculty`, { login: false, msg:'' });
    }
})

router.post('/insert', (req, res) => {
    let body = req.body;
    body['facultyid'] = req.session.facultyid
 pool.query(`insert into ${table} set ?`, body, (err, result) => {
        if(err) throw err;
        else res.send('success')
    })
})



router.get('/all', (req, res) => {
    pool.query(`select q.* , (select qu.name from quiz_name qu where qu.id = q.quizid) as quizname from ${table} q where q.facultyid = "${req.session.facultyid}"`, (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})

// router.get('/single', (req, res) => {
//     const { id } = req.query
//     pool.query(`select * from ${table} where id = ${id}`, (err, result) => {
//         if(err) throw err;
//         else res.json(result);
//     })
// })

router.get('/delete', (req, res) => {
    const { id } = req.query
    pool.query(`delete from ${table} where id = ${id}`, (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})

router.post('/update', (req, res) => {
    console.log(req.body)
    pool.query(`update ${table} set ? where id = ?`, [req.body, req.body.id], (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})



module.exports = router;