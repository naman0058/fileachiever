var express = require('express')
var pool = require('./pool')
var router = express.Router()

// var upload = require('./multer');


router.get('/', (req, res) => {
    if(req.session.facultyid) {
//         pool.query(`select d.price,(
//             select count(id) from users) as totalusers,
//             (select count(id) from drive) as soldnotes,
//             (select sum(price) from drive) as totalprice,
//             (select a.name from admin a where a.id='${req.session.adminid}') as adminname,
//             (select count(id) from answer) as totalnotes,
//             (select a.name from answer a where a.id=d.notesid) as notesname,
//             (select u.name from users u where u.id=d.userid) as username  from drive d `, (err, result) => {          
//               if(err) throw err;
// else if(result)   
//       res.render(`adminhome`, { login: true,result:result});
//       else res.redirect('/404')
//         })

res.render(`facultyhome`,{login:true})
    }

    else {
        res.redirect('/faculty')
    }
})


router.get('/results',(req,res)=>{
    pool.query(`select r.*, (select q.name from quiz_name q where q.id = r.quizid) as quizname, (select qu.name from quiz_topic qu where qu.id = r.quiztopicid) as quiztopicname , (select s.name from student s where s.id = r.studentid ) as studentname from result r where r.studentid = "${req.session.facultyid}" order by id desc`,(err,result)=>{
      if(err) console.log(err)
      else res.render('student_result',{result:result})
    })
    })
    


module.exports = router;

