var express = require('express')
var pool = require('./pool')
var router = express.Router()
var table = 'study_materials_notes';
var upload = require('./multer');

router.get('/', (req, res) => {
    if(req.session.facultyid) {
    res.render(`${table}/index`);
    }
    else
    {
         res.render(`faculty`, { login: false, msg:'' });
    }
})

router.post('/insert',upload.single('pdf'), (req, res) => {
    let body = req.body;
    body['facultyid'] = req.session.facultyid
    body['pdf'] = req.file.filename
    pool.query(`insert into ${table} set ?`, body, (err, result) => {
        if(err) throw err;
        else res.redirect('/study_materials_notes')
    })
})




router.get('/all_category',(req,res)=>{
    pool.query(`select * from study_materials_category`,(err,result)=>{
        err ? console.log(err) : res.json(result)
    })
})


router.get('/all', (req, res) => {
    pool.query(`select s.* , (select sc.name from study_materials_category sc where sc.id = s.studymaterialsid) as studymaterialsname from ${table} s where s.facultyid = "${req.session.facultyid}"`, (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})

// router.get('/single', (req, res) => {
//     const { id } = req.query
//     pool.query(`select * from ${table} where id = ${id}`, (err, result) => {
//         if(err) throw err;
//         else res.json(result);
//     })
// })

router.get('/delete', (req, res) => {
    const { id } = req.query
    pool.query(`delete from ${table} where id = ${id}`, (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})

router.post('/update', (req, res) => {
    console.log(req.body)
    pool.query(`update ${table} set ? where id = ?`, [req.body, req.body.id], (err, result) => {
        if(err) throw err;
        else res.json(result);
    })
})



router.post('/update_image',upload.single('pdf'), (req, res) => {
    let body = req.body;

    body['pdf'] = req.file.filename

    pool.query(`update ${table} set ? where id = ?`, [req.body, req.body.id], (err, result) => {
        if(err) throw err;
        else res.redirect('/study_materials_notes')
    })
})


module.exports = router;