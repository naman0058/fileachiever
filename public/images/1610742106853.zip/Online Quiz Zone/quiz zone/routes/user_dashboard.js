var express = require('express');
var router = express.Router();
var pool = require('./pool')

/* GET home page. */
router.get('/', function(req, res, next) {
  if(req.session.studentid){
    var query = `select * from quiz_name;`
    var query1 = `select * from student where id = "${req.session.studentid}";`
    pool.query(query+query1,(err,result)=>{
      if(err) throw err;
      else   res.render('user_dashboard',{result:result});
    })
  }
  else{
res.redirect('/user-login')
  }
 

});


router.get('/quiz/:id', function(req, res, next) {
  if(req.session.studentid){
  console.log(req.params.id)
  var query = `select * from quiz_topic where quizid = "${req.params.id}";`
  var query1 = `select * from student where id = "${req.session.studentid}";`
  pool.query(query+query1,(err,result)=>{
    if(err) throw err;
    else  res.render('quiz',{result:result});
  })
}
else res.redirect('/user-login')
});

router.get('/quiz/quiz-instrution/:id', function(req, res, next) {
  if(req.session.studentid){
    console.log(req.params.id)
    var query = `select * from create_quiz where quizid = "${req.params.id}";`
    pool.query(query,(err,result)=>{
      if(err) throw err;
      else  res.render('startquiz',{result:result});
    })
  }
  else res.redirect('/user-login')
  });


  router.get('/subject',(req,res)=>{
    res.render('subject')
  })






router.get('/results',(req,res)=>{
pool.query(`select r.*, (select q.name from quiz_name q where q.id = r.quizid) as quizname, (select qu.name from quiz_topic qu where qu.id = r.quiztopicid) as quiztopicname , (select s.name from student s where s.id = r.studentid ) as studentname from result r where r.studentid = "${req.session.studentid}" order by id desc`,(err,result)=>{
  if(err) console.log(err)
  else res.render('student_result',{result:result})
})
})


module.exports = router;
