var express = require('express');
var router = express.Router();
var pool = require('./pool')


/* GET home page. */
router.get('/', function(req, res, next) {
  if(req.session.studentid)
  res.render('startquiz');
  else res.redirect('/user-login')
});


router.post('/result',(req,res)=>{
  let body = req.body
  pool.query(`select answer from create_quiz where id = "${req.body.id}" and quizid = "${req.body.quizid}" and quiztopicid = "${req.body.quiztopicid}" `,(err,result)=>{
if(err) throw err;
else {
  console.log(result[0].answer)
  console.log(req.body.answer)
  if(req.body.answer == result[0].answer){
    res.send('2')
  }
  else{
   res.send('0')
  }
  
}
  })
})



router.post('/insert/result',(req,res)=>{
  let body = req.body
  console.log(req.body)
  body['studentid'] = req.session.studentid
  body['correct_answer'] = req.body.result/2
  body['uncorrect_answer'] = req.body.total_question - (req.body.result/2)
  pool.query(`insert into result set ?`, body, (err, result) => {
    if(err) throw err;
    else res.send('success')
})
})




router.get('/results',(req,res)=>{
  pool.query(`select total_question , uncorrect_answer , correct_answer , result from result where studentid = '${req.session.studentid}' order by id desc limit 1`,(err,result)=>{
    if(err) throw err;
    else res.render(`result`,{result:result})
  })
})


module.exports = router;
