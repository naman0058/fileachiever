var express = require('express');
var router = express.Router();
var mysql = require('mysql')
var pool = require('./pool')
var table = 'admin'


router.get('/', (req, res) => {
  res.render(`${table}`,{msg : ''});
})

router.post('/login', (req, res) => {
  const { email, password } = req.body
  console.log(req.body)
  pool.query(`select * from ${table} where email = "${email}" and password = "${password}"`, (err, result) => {
      if (result[0]) {
          console.log(result[0].id)
          req.session.adminid = result[0].id;
          res.redirect('/adminhome');
      }
      else
          res.render('admin',{msg : 'Invalid Creaditianils'});
  })
})


router.get('/logout', (req, res) => {
  req.session.adminid = null;
  res.redirect('/admin');
})

module.exports = router;
















