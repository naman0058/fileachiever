var express = require('express');
var router = express.Router();
var mysql = require('mysql')
var pool = require('./pool')
var table = 'faculty'


router.get('/', (req, res) => {

    res.render(`${table}`,{msg : ''});
})

router.post('/login', (req, res) => {
  const { email, password } = req.body
  console.log(req.body)
  pool.query(`select * from ${table} where email = "${email}" and password = "${password}"`, (err, result) => {
    if(err) throw err 
    else if (result[0]) {
           req.session.facultyid = result[0].id;
          res.redirect('/facultyhome');
      }
      else
          res.render('faculty',{msg : 'Invalid Creaditianils'});
  })
})


router.get('/logout', (req, res) => {
  req.session.facultyid = null;
  res.redirect('/faculty');
})

module.exports = router;
















