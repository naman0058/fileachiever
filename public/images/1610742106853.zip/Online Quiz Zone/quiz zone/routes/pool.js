var mysql = require('mysql')

const pool = mysql.createPool({
   
    //  host:'localhost',
host:'134.209.151.182',
    user: 'root',
//   password: '',
password:'manraspaamanraspaa',
    database: 'quiz_zone',
    port:'3306' ,
    multipleStatements: true
  })


module.exports = pool;