var createError = require('http-errors');
var cookieSession = require('cookie-session')
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
// var usersRouter = require('./routes/users');
// var usersDashboard = require('./routes/user_dashboard');
// var quiz = require('./routes/quiz');
// var faculity = require('./routes/faculty');
// var faculityhome = require('./routes/facultyhome');
// var create_quiz = require('./routes/create_quiz');
// var quiz_name = require('./routes/quiz_name');
// var quiz_topic = require('./routes/quiz_topic');
// var admin = require('./routes/admin');
// var adminhome = require('./routes/adminhome')
// var study_materials_notes = require('./routes/study_materials_notes')
// var study_materials = require('./routes/study_materials')
// var study_material_category = require('./routes/study_material_category')
// var add_group = require('./routes/add_group')
// var add_faculty = require('./routes/add_faculty')
// var add_student = require('./routes/add_student')
   var shoes = require('./routes/shoes');
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.set('trust proxy', 1)

app.use(cookieSession({
  name: 'session',
  keys: ['quizzone'],
 
  // Cookie Options
  maxAge: 24 * 60 * 60 * 1000 // 24 hours
}))

app.use('/', indexRouter);
// app.use('/user-login', usersRouter);
// app.use('/user-dashboard', usersDashboard);
// app.use('/quiz',quiz);
// app.use('/faculty',faculity)
// app.use('/facultyhome',faculityhome)
// app.use('/create_quiz',create_quiz)
// app.use('/quiz_name',quiz_name)
// app.use('/quiz_topic',quiz_topic)
// app.use('/admin_login',admin)
// app.use('/study_materials_notes',study_materials_notes)
// app.use('/study_materials',study_materials)
// app.use('/adminhome',adminhome)
// app.use('/study_material_category',study_material_category)
// app.use('/add_group',add_group)
// app.use('/add_faculty',add_faculty);
// app.use('/add_student',add_student);
app.use('/shoes',shoes)
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});





// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
