# Ecommerce PHP MySQL Stripe

This project is an eCommerce web application built with PHP, MySQL, and Stripe integration.

## Database Setup

- Database Name: `ecommerceweb`
- Recommended PHP Version: 5.6 or 7.4

## Customer Verification

Customer verification is done by accessing the database and changing the active status.

## Admin Login Details

- Email: admin@mail.com
- Password: Password@123
