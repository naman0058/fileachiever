#!/bin/bash

php -S localhost:8080

echo "http://localhost:8080"