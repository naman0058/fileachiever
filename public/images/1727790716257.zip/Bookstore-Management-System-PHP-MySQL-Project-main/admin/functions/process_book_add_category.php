<?php

    $category_query = "SELECT * FROM `category_table`";
    $category_result = mysqli_query($connection_database, $category_query);

?>