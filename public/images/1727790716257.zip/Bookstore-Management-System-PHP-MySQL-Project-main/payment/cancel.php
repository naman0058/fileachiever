<?php
    include("../includes/header.php");
?>

        <div class="mh-100" style="height:500px">
            <br>
            <h1 class="text-center h-50">Sorry! Your PayPal Payment has been cancelled.</h1>
        </div>
 
<?php
    include("../includes/footer.php");
?>