<div class="cpy-right text-center">
        <p> Online Nurse Hiring System
            
        </p>
    </div>