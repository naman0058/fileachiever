<?php
// Establish a connection to the database
$servername = "localhost";
$username = "bosvesedst_root";
$password = "filemakrxpert@123";
$dbname = "bosvesedst_online_food_ordering";

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>
