<footer class="page-footer">
                <div class="font-13">Blood Donor Management System</div>
        
                <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
            </footer>